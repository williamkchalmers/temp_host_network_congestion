## Compile
```
nvcc -o gpu_stress gpu_stress.cu
```