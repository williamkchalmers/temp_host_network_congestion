from .app import main

import sys

main(sys.argv)